Sqoon NES Text Editor
Programmed by: sleepy9090
Last Update: July 4th, 2017 in C#
Latest Build: 1.0
 ----

Features:
	* edit every line of text in the game
	* this version tested with the standard USA headered rom, might work with other versions but untested because it relies on offsets in the ROM

Requires:
	* .Net Framework 3.5

Usage:
	*Open the Rom, change text, click "Update Text", make sure you have a backup in case something breaks.
	*Feel free to email bugs to sleepy3d@gmail.com

 ----
1.0  July 4th, 2017
-initial release
 ----